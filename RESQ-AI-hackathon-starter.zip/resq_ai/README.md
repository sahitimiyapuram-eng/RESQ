# RESQ-AI Hackathon Starter

AI-assisted emergency triage + explainability + mistriage consistency check + deterioration alerts + resource-aware flags + command-center frontend.

## Run backend
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000

## Run frontend
cd frontend
npm install
npm run dev

Open http://localhost:5173 and API docs at http://localhost:8000/docs.

## Retrain
cd backend
python train_model.py

## ML target
KTAS_expert. The training script excludes KTAS_RN, mistriage, diagnosis, disposition and post-arrival timing/outcome fields to reduce leakage.

## Important
This is a hackathon prototype and not a medical device. It must not be used for autonomous diagnosis, treatment or triage. Real deployment requires clinical validation, privacy/security controls, interoperability, monitoring and regulatory review.
