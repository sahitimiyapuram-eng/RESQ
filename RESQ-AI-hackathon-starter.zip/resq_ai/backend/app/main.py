from pathlib import Path
from datetime import datetime, timezone
import json, uuid
import joblib, pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

BASE=Path(__file__).resolve().parent.parent
model=joblib.load(BASE/'models'/'triage_model.joblib')
metrics=json.loads((BASE/'models'/'metrics.json').read_text())
app=FastAPI(title='RESQ-AI API',version='0.1.0')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_methods=['*'],allow_headers=['*'])
patients={}
history={}
resources={'icu_beds':2,'emergency_beds':5,'oxygen_units':18,'ventilators':4,'doctors':4,'nurses':9,'cardiologists':1,'neurologists':1}

class Assessment(BaseModel):
    patient_id:str|None=None; age:float=50; sex:int=1; patients_per_hour:float=5; arrival_mode:int=3; injury:int=1
    chief_complaint:str='chest pain'; mental:int=1; pain:int=1; nrs_pain:float=5; sbp:float=120; dbp:float=80
    hr:float=80; rr:float=18; bt:float=36.7; saturation:float|None=98

class Vitals(BaseModel):
    sbp:float; hr:float; rr:float; saturation:float|None=None

class ResourceUpdate(BaseModel):
    icu_beds:int; emergency_beds:int; oxygen_units:int; ventilators:int; doctors:int; nurses:int; cardiologists:int; neurologists:int

def frame(a):
    return pd.DataFrame([{'Group':1,'Sex':a.sex,'Age':a.age,'Patients number per hour':a.patients_per_hour,'Arrival mode':a.arrival_mode,'Injury':a.injury,'Chief_complain':a.chief_complaint,'Mental':a.mental,'Pain':a.pain,'NRS_pain':a.nrs_pain,'SBP':a.sbp,'DBP':a.dbp,'HR':a.hr,'RR':a.rr,'BT':a.bt,'Saturation':a.saturation}])

def explain(a):
    r=[]
    if a.saturation is not None and a.saturation<92:r.append('Low oxygen saturation')
    if a.sbp<90:r.append('Low systolic blood pressure')
    if a.hr>110:r.append('Elevated heart rate')
    if a.rr>24:r.append('Elevated respiratory rate')
    if a.nrs_pain>=7:r.append('High pain score')
    if a.mental!=1:r.append('Abnormal mental status')
    return r or ['No single extreme vital sign dominates the assessment']

def risk(k): return 'CRITICAL' if k==1 else 'HIGH' if k==2 else 'MODERATE' if k==3 else 'LOW'

def deterioration(pid):
    h=history.get(pid,[])
    if len(h)<2:return {'alert':False,'reasons':[],'message':'Need at least two vital observations.'}
    p,c=h[-2],h[-1]; r=[]
    if c['saturation'] is not None and p['saturation'] is not None and c['saturation']<p['saturation']-3:r.append('SpO₂ is falling')
    if c['hr']>p['hr']+15:r.append('Heart rate is rising')
    if c['rr']>p['rr']+5:r.append('Respiratory rate is rising')
    if c['sbp']<p['sbp']-15:r.append('Systolic blood pressure is falling')
    return {'alert':bool(r),'reasons':r,'message':'Potential deterioration pattern detected.' if r else 'No major worsening trend detected.'}

def resource_flags(k,a):
    r=[]
    if k<=2:r.append('Verify high-acuity bed availability')
    if k<=2 and a.saturation is not None and a.saturation<92:r.append('Check oxygen-support capacity')
    if resources['icu_beds']==0 and k<=2:r.append('No ICU beds available — escalate capacity coordination')
    if resources['oxygen_units']<=3 and a.saturation is not None and a.saturation<92:r.append('Oxygen inventory is low')
    if a.chief_complaint.lower() in ['chest pain','palpitations'] and resources['cardiologists']>0:r.append('Cardiology team is available for notification')
    return r

@app.get('/api/health')
def health(): return {'status':'ok','model_loaded':True}
@app.get('/api/model-metrics')
def model_metrics(): return metrics
@app.get('/api/resources')
def get_resources(): return resources
@app.put('/api/resources')
def put_resources(x:ResourceUpdate): resources.update(x.model_dump()); return resources
@app.get('/api/patients')
def get_patients(): return list(patients.values())

@app.post('/api/triage/predict')
def predict(a:Assessment):
    pid=a.patient_id or f'P{uuid.uuid4().hex[:6].upper()}'
    a.patient_id=pid
    pred=int(model.predict(frame(a))[0]); proba=model.predict_proba(frame(a))[0]; conf=float(max(proba))
    rec={**a.model_dump(),'predicted_ktas':pred,'risk_level':risk(pred),'confidence':conf,'explanations':explain(a),'resource_flags':resource_flags(pred,a),'deterioration':deterioration(pid),'timestamp':datetime.now(timezone.utc).isoformat(),'initial_ktas':None,'potential_mistriage':False,'status':'Awaiting clinical review'}
    patients[pid]=rec; return rec

@app.post('/api/patients/{pid}/vitals')
def add_vitals(pid:str,v:Vitals):
    if pid not in patients: raise HTTPException(404,'Patient not found')
    history.setdefault(pid,[]).append(v.model_dump()); patients[pid]['deterioration']=deterioration(pid); return patients[pid]['deterioration']

@app.post('/api/mistriage/check/{pid}')
def mistriage(pid:str,initial_ktas:int):
    if pid not in patients: raise HTTPException(404,'Patient not found')
    ai=patients[pid]['predicted_ktas']; mismatch=abs(ai-initial_ktas)>=1
    patients[pid]['initial_ktas']=initial_ktas; patients[pid]['potential_mistriage']=mismatch
    return {'patient_id':pid,'initial_ktas':initial_ktas,'ai_ktas':ai,'potential_mistriage':mismatch,'message':'Potential triage discrepancy — clinical review recommended.' if mismatch else 'No discrepancy detected by this prototype consistency check.'}

@app.get('/api/alerts')
def alerts():
    out=[]
    for p in patients.values():
        if p.get('potential_mistriage'):out.append({'type':'mistriage','patient_id':p['patient_id'],'message':'Potential triage discrepancy — clinical review recommended.'})
        if p.get('deterioration',{}).get('alert'):out.append({'type':'deterioration','patient_id':p['patient_id'],'message':p['deterioration']['message'],'reasons':p['deterioration']['reasons']})
    if resources['oxygen_units']<=3:out.append({'type':'resource','message':'Oxygen inventory is low.'})
    if resources['icu_beds']==0:out.append({'type':'resource','message':'No ICU beds currently available.'})
    return out

@app.get('/api/copilot/{pid}')
def copilot(pid:str):
    if pid not in patients:raise HTTPException(404,'Patient not found')
    p=patients[pid]
    return {'patient_id':pid,'summary':f"Patient {pid} is predicted KTAS {p['predicted_ktas']} ({p['risk_level']}). Key factors: {', '.join(p['explanations'])}.",'disclaimer':'Decision-support prototype; qualified clinicians retain final responsibility.'}
