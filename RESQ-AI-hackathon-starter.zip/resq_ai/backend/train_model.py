
import joblib
import json
import pandas as pd
from pathlib import Path
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, f1_score, accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

BASE = Path(__file__).resolve().parent
DATA = BASE / "data" / "data.csv"
MODEL_DIR = BASE / "models"
MODEL_DIR.mkdir(exist_ok=True)

df = pd.read_csv(DATA, sep=";", encoding="latin1", decimal=",")

# Target: expert KTAS assessment.
target = "KTAS_expert"

# Only use information that can reasonably be available at initial triage.
# Post-treatment/outcome fields and the RN target-like assessment are excluded.
drop_cols = [
    target,
    "KTAS_RN",
    "Error_group",
    "Length of stay_min",
    "KTAS duration_min",
    "mistriage",
    "Disposition",
    "Diagnosis in ED",
]

drop_cols = [c for c in drop_cols if c in df.columns]
X = df.drop(columns=drop_cols)
y = pd.to_numeric(df[target], errors="coerce")

mask = y.notna()
X, y = X.loc[mask].copy(), y.loc[mask].astype(int)

# Normalize the text field.
if "Chief_complain" in X.columns:
    X["Chief_complain"] = X["Chief_complain"].fillna("").astype(str)

text_col = "Chief_complain"
numeric_cols = [c for c in X.columns if c != text_col and pd.api.types.is_numeric_dtype(X[c])]
categorical_cols = [c for c in X.columns if c != text_col and c not in numeric_cols]

numeric_pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
])

categorical_pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore")),
])

transformers = [
    ("num", numeric_pipe, numeric_cols),
    ("cat", categorical_pipe, categorical_cols),
]

if text_col in X.columns:
    transformers.append((
        "complaint",
        TfidfVectorizer(max_features=300, ngram_range=(1, 2), lowercase=True),
        text_col,
    ))

preprocessor = ColumnTransformer(transformers, remainder="drop")

model = RandomForestClassifier(
    n_estimators=350,
    max_depth=None,
    class_weight="balanced_subsample",
    random_state=42,
    n_jobs=-1,
)

pipe = Pipeline([
    ("preprocess", preprocessor),
    ("model", model),
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, stratify=y, random_state=42
)

pipe.fit(X_train, y_train)
pred = pipe.predict(X_test)

metrics = {
    "accuracy": float(accuracy_score(y_test, pred)),
    "macro_f1": float(f1_score(y_test, pred, average="macro")),
    "weighted_f1": float(f1_score(y_test, pred, average="weighted")),
    "classes": sorted([int(v) for v in y.unique().tolist()]),
    "train_rows": int(len(X_train)),
    "test_rows": int(len(X_test)),
    "features": list(X.columns),
    "report": classification_report(y_test, pred, output_dict=True, zero_division=0),
}

joblib.dump(pipe, MODEL_DIR / "triage_model.joblib")
(MODEL_DIR / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")

print(json.dumps({
    "rows": len(df),
    "train_rows": len(X_train),
    "test_rows": len(X_test),
    "accuracy": metrics["accuracy"],
    "macro_f1": metrics["macro_f1"],
}, indent=2))
